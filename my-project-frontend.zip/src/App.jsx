import MultiStepForm from "./components/pages/MultiStepForm";

const App = () => {
  return (
    <div>
      <MultiStepForm />
    </div>
  );
};

export default App;
